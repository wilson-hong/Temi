package com.hanyang.temi.network;

import static com.hanyang.temi.network.Network.IPTOS_LOWDELAY;
import static com.hanyang.temi.network.Network.IPTOS_THROUGHPUT;
import static com.hanyang.temi.network.Network.STATUS_CONNECTED;
import static com.hanyang.temi.network.Network.STATUS_DISCONNECTED;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

public class ControlThread extends Thread{
    private ServerSocket controlServerSocket;
    private Socket controlSocket;
    private ControlSocketCallback controlSocketCallback;
    private int status = STATUS_DISCONNECTED;
    private UUID playerUUID;

    public ControlThread(int port) {
        try {
            controlServerSocket = new ServerSocket(port);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setControlSocketCallback(ControlSocketCallback controlSocketCallback) {
        this.controlSocketCallback = controlSocketCallback;
    }

    public int getStatus() {
        return status;
    }

    @Override
    public void run() {
        InputStream inputStream;
        DataInputStream dataInputStream;
        int cmd;

        try {
            controlSocket = controlServerSocket.accept();
            controlSocket.setTcpNoDelay(true);
            controlSocket.setTrafficClass(IPTOS_THROUGHPUT | IPTOS_LOWDELAY);

            inputStream = controlSocket.getInputStream();
            dataInputStream = new DataInputStream(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
            status = STATUS_DISCONNECTED;
            if (controlSocketCallback != null) {
                controlSocketCallback.onError();
            }
            return;
        }

        long mostSigBits, leastSigBits;
        try {
            mostSigBits = dataInputStream.readLong();
            leastSigBits = dataInputStream.readLong();
            playerUUID =  new UUID(mostSigBits, leastSigBits);
        } catch (IOException e) {
            e.printStackTrace();
        }

        status = STATUS_CONNECTED;
        if (controlSocketCallback != null) {
            controlSocketCallback.onConnected();
        }

        while (!Thread.currentThread().isInterrupted()) {
            try {
                cmd = dataInputStream.readInt();
                if (controlSocketCallback != null) {
                    controlSocketCallback.onCommandReceived(cmd);
                }
            } catch (IOException e) {
                if (controlSocketCallback != null) {
                    controlSocketCallback.onError();
                }
                e.printStackTrace();
                break;
            }
        }

        status = STATUS_DISCONNECTED;
        clean();
    }

    public void clean() {
        if (controlServerSocket != null) {
            try {
                controlServerSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            controlServerSocket = null;
        }

        if (controlSocket != null) {
            try {
                controlSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            controlSocket = null;
        }
    }

    public UUID getPlayerUUID() {
        return playerUUID;
    }
}
