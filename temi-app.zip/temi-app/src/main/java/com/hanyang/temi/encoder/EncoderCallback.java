package com.hanyang.temi.encoder;

import com.hanyang.temi.network.EncodedData;

public interface EncoderCallback {
    void onDataEncoded(EncodedData data);

    default void onError() {};
}
