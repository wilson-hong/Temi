package com.hanyang.temi.camera;

import android.hardware.camera2.CameraDevice;

import androidx.annotation.NonNull;

public interface CameraStateCallback {
    default void onOpened(@NonNull CameraDevice camera) {};

    default void onDisconnected(@NonNull CameraDevice camera) {};

    default void onError(@NonNull CameraDevice camera, int error) {};
}
