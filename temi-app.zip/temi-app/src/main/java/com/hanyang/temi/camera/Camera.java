package com.hanyang.temi.camera;

import static android.hardware.camera2.CameraMetadata.LENS_FACING_BACK;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Size;
import android.view.Surface;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.hanyang.temi.encoder.Encoder;

import java.util.ArrayList;
import java.util.List;

public class Camera {
    private Context context;
    private String cameraId;
    private Size[] outputSizes;
    private Size outputSize;
    private CameraDevice cameraDevice;
    private CameraCaptureSession cameraCaptureSession;
    private CaptureRequest captureRequest;
    private CaptureRequest.Builder captureRequestBuilder;
    private CameraStateCallback cameraStateCallback;
    private HandlerThread captureThread;
    private Handler captureHandler;

    public Camera(Context context) {
        this.context = context;
    }

    private void startCaptureThread() {
        if (captureThread == null) {
            captureThread = new HandlerThread("Capture Thread");
            captureThread.start();
            captureHandler = new Handler(captureThread.getLooper());
        }
    }

    private void stopCaptureThread() throws InterruptedException {
        if (captureThread != null) {
            captureThread.quitSafely();
            captureThread.join();
            captureThread = null;
            captureHandler = null;
        }
    }

    public boolean open(int lensFacing, int width, int hetght) throws CameraAccessException {
        CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);

        cameraId = "";
        for (String cameraId : manager.getCameraIdList()) {
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
            if (characteristics.get(characteristics.LENS_FACING) == lensFacing) {
                this.cameraId = cameraId;
                StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                outputSizes = map.getOutputSizes(SurfaceTexture.class); // ImageFormat.JPEG, SurfaceTexture.class
                outputSize = null;
                for (Size size : outputSizes) {
                    if (size.getWidth() == width && size.getHeight() == hetght) {
                        outputSize = size;
                        break;
                    }
                }

                if (outputSize != null) {
                    break;
                }
            }
        }

        if (cameraId.isEmpty() || outputSize == null) {
            return false;
        }

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        startCaptureThread();

        manager.openCamera(cameraId, stateCallback, captureHandler);

        return true;
    }

    private CameraDevice.StateCallback stateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@NonNull CameraDevice camera) {
            cameraDevice = camera;
            if (cameraStateCallback != null) {
                cameraStateCallback.onOpened(camera);
            }
        }

        @Override
        public void onDisconnected(@NonNull CameraDevice camera) {
            clean();
            if (cameraStateCallback != null) {
                cameraStateCallback.onDisconnected(camera);
            }
        }

        @Override
        public void onError(@NonNull CameraDevice camera, int error) {
            clean();
            if (cameraStateCallback != null) {
                cameraStateCallback.onError(camera, error);
            }
        }
    };

    public void startCapture(List<Surface> outputSurfaces) throws CameraAccessException {
        captureRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
        for (Surface surface : outputSurfaces) {
            captureRequestBuilder.addTarget(surface);
        }

        cameraDevice.createCaptureSession(outputSurfaces, new CameraCaptureSession.StateCallback() {
            @Override
            public void onConfigured(@NonNull CameraCaptureSession session) {
                cameraCaptureSession = session;

                try {
                    createCaptureRequest();
                } catch (CameraAccessException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onConfigureFailed(@NonNull CameraCaptureSession session) {}
        }, captureHandler);
    }

    private void createCaptureRequest() throws CameraAccessException {
        captureRequestBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
        captureRequest = captureRequestBuilder.build();

        cameraCaptureSession.setRepeatingRequest(captureRequest, null, captureHandler);
    }

    public void stopCapture() {
        if (cameraCaptureSession != null) {
            cameraCaptureSession.close();
            cameraCaptureSession = null;
        }
    }

    public void clean() {
        stopCapture();

        if (cameraDevice != null) {
            cameraDevice.close();
            cameraDevice = null;
        }

        if (captureThread != null) {
            try {
                stopCaptureThread();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public CameraDevice getCameraDevice() {
        return cameraDevice;
    }

    public void setCameraStateCallback(CameraStateCallback cameraStateCallback) {
        this.cameraStateCallback = cameraStateCallback;
    }
}
