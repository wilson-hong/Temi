package com.hanyang.temi.control;

public class ControlState {
    public boolean forward;
    public boolean backward;
    public boolean left;
    public boolean right;
    public boolean up;
    public boolean down;
}
