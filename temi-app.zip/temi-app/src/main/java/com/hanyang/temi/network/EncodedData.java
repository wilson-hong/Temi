package com.hanyang.temi.network;


import android.os.Parcel;
import android.os.Parcelable;


public class EncodedData {
    public byte[] bytes;
    public long timeUs;

    public EncodedData(byte[] bytes, long timeUs) {
        this.bytes = bytes;
        this.timeUs = timeUs;
    }
}