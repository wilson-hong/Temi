package com.hanyang.temi.network;

public interface VideoSocketCallback {
    void onConnected();

    default void onError() {};
}
