package com.hanyang.temi;

import android.app.Application;

import com.hanyang.temi.bluetooth.BluetoothManager;
import com.hanyang.temi.network.Network;

public class TemiApplication extends Application {
    private BluetoothManager bluetoothManager = new BluetoothManager(this);
    private Network network = new Network();

    public BluetoothManager getBluetoothManager() {
        return bluetoothManager;
    }

    public void setBluetoothManager(BluetoothManager bluetoothManager) {
        this.bluetoothManager = bluetoothManager;
    }

    public Network getNetwork() {
        return network;
    }

    public void setNetwork(Network network) {
        this.network = network;
    }
}

