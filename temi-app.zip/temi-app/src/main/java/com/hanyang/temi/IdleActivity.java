package com.hanyang.temi;

import static android.hardware.camera2.CameraMetadata.LENS_FACING_BACK;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Surface;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.hanyang.temi.camera.Camera;
import com.hanyang.temi.control.Control;
import com.hanyang.temi.encoder.Encoder;
import com.hanyang.temi.network.ControlSocketCallback;
import com.hanyang.temi.network.Network;
import com.hanyang.temi.network.WebSocketCallback;
import com.hanyang.temi.network.dto.WebSocketMessage;
import com.robotemi.sdk.Robot;

import java.util.ArrayList;
import java.util.List;

public class IdleActivity extends AppCompatActivity {
    private TemiApplication temiApplication;
    private Network network;
    private Robot robot;

    private ImageView imageView;
    private ImageButton backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_idle);
        temiApplication = (TemiApplication) getApplication();
        network = temiApplication.getNetwork();

        robot = Robot.getInstance();

        imageView = (ImageView)findViewById(R.id.imageView);
        backButton = (ImageButton) findViewById(R.id.backButton);

        network.cleanPlayer();
        network.start();

        network.setControlSocketCallback(new ControlSocketCallback() {
            @Override
            public void onError() {
                network.sendToServer("PLAYER_DISCONNECTED", "");
                Intent intent = new Intent(getApplicationContext(), IdleActivity.class);
                startActivity(intent);
                finishAffinity();
            }

            @Override
            public void onConnected() {
                Log.d("D", "getPlayerUUID: " + network.getPlayerUUID());
                network.sendToServer("PLAYER_CONNECTED", network.getPlayerUUID().toString());
                Intent intent = new Intent(getApplicationContext(), GameActivity.class);
                startActivity(intent);
                finishAffinity();
            }
        });

        network.setWebSocketCallback(new WebSocketCallback() {
            @Override
            public void onConnected() {}

            @Override
            public void onDisonnected() {
                runOnUiThread(() -> Toast.makeText(getApplicationContext(), "Server Disconnected", Toast.LENGTH_SHORT).show());
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finishAffinity();
            }
        });

        backButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(intent);
            finishAffinity();
        });
    }
}
