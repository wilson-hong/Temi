package com.hanyang.temi.encoder;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.hanyang.temi.network.EncodedData;
import com.hanyang.temi.network.Network;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Encoder {
    private MediaCodec codec;
    private Surface input;
    HandlerThread encodeThread;
    Handler encodeHandler;
    EncoderCallback encoderCallback;

    public Encoder() {}

    public void start() {
        initCodec();
        startEncodeThread();

        if (codec != null) {
            codec.start();
        }
    }

    private void startEncodeThread() {
        if (encodeThread == null) {
            encodeThread = new HandlerThread("Encoder Thread");
            encodeThread.start();
            encodeHandler = new Handler(encodeThread.getLooper());
        }
    }

    private void stopEncodeThread() throws InterruptedException {
        if (encodeThread != null) {
            encodeThread.quitSafely();
            encodeThread.join();
            encodeThread = null;
            encodeHandler = null;
        }
    }

    private void initCodec() {
        if (codec != null) {
            return;
        }

        MediaFormat videoFormat = getVideoFormat();
        String encoderCodecName = new MediaCodecList(MediaCodecList.REGULAR_CODECS).findEncoderForFormat(videoFormat);
        if (encoderCodecName.isEmpty()) {
            Toast.makeText(null, "Codec not found.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            codec = MediaCodec.createByCodecName(encoderCodecName);
        } catch (IOException e) {
            e.printStackTrace();
        }
        codec.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);

        input = codec.createInputSurface();

        codec.setCallback(new MediaCodec.Callback() {
            @Override
            public void onInputBufferAvailable(@NonNull MediaCodec codec, int index) {
            }

            @Override
            public void onOutputBufferAvailable(@NonNull MediaCodec codec, int index, @NonNull MediaCodec.BufferInfo info) {
                ByteBuffer outputBuffer = codec.getOutputBuffer(index);
                byte[] bytes = new byte[outputBuffer.remaining()];
                outputBuffer.get(bytes);

                EncodedData data = new EncodedData(bytes, info.presentationTimeUs);

                if (encoderCallback != null) {
                    encoderCallback.onDataEncoded(data);
                }

                outputBuffer.clear();
                codec.releaseOutputBuffer(index, false);

                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    codec.stop();
                    codec.release();
                }
            }

            @Override
            public void onError(@NonNull MediaCodec codec, @NonNull MediaCodec.CodecException e) {
                if (encoderCallback != null) {
                    encoderCallback.onError();
                }
                clean();
            }

            @Override
            public void onOutputFormatChanged(@NonNull MediaCodec codec, @NonNull MediaFormat format) {
            }
        }, encodeHandler);
    }

    private MediaFormat getVideoFormat() {
        MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, 1280, 720);
        videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, 8000000);
        videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
        videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface); //COLOR_FormatYUV420Planar, COLOR_FormatSurface, COLOR_FormatYUV420Flexible
        videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

        return videoFormat;
    }

    public void setEncoderCallback(EncoderCallback encoderCallback) {
        this.encoderCallback = encoderCallback;
    }

    public Surface getInputSurface() {
        return input;
    }

    public void clean() {
        try {
            stopEncodeThread();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (codec != null) {
            codec.stop();
            codec.release();
            codec = null;
        }
    }
}
