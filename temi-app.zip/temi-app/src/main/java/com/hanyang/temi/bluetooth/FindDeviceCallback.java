package com.hanyang.temi.bluetooth;

import android.bluetooth.BluetoothDevice;

public interface FindDeviceCallback {
    default void onFindDevice(String deviceName, BluetoothDevice newDevice) {}
}
