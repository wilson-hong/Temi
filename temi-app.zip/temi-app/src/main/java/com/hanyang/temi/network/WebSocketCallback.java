package com.hanyang.temi.network;

import com.hanyang.temi.network.dto.WebSocketMessage;

public interface WebSocketCallback {
    void onConnected();

    default void onDisonnected() {};

    default void onReceiveMessage(WebSocketMessage webSocketMessage) {};

    default void onError() {};
}
