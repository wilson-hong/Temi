package com.hanyang.temi;

import android.Manifest;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattDescriptor;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.hanyang.temi.bluetooth.BluetoothManager;
import com.hanyang.temi.bluetooth.FindDeviceCallback;
import com.hanyang.temi.bluetooth.GattCallback;
import com.hanyang.temi.network.Network;
import com.robotemi.sdk.Robot;

public class MainActivity extends AppCompatActivity {
    private int REQUEST_CODE_PERMISSIONS = 1001;
    private final String[] REQUIRED_PERMISSIONS = new String[]{
            Manifest.permission.BLUETOOTH,
            Manifest.permission.BLUETOOTH_ADMIN,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.INTERNET,
            Manifest.permission.WAKE_LOCK
    };

    private TemiApplication temiApplication;
    private BluetoothManager bluetoothManager;
    private Network network;
    private Robot robot;
    Handler handler = new Handler();

    private ImageButton startButton, exitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        temiApplication = (TemiApplication) getApplication();
        bluetoothManager = temiApplication.getBluetoothManager();
        network = temiApplication.getNetwork();
        robot = Robot.getInstance();

        startButton = (ImageButton) findViewById(R.id.startButton);
        exitButton = (ImageButton) findViewById(R.id.exitButton);

        startButton.setOnClickListener(view -> {
            if (bluetoothManager.getConnectionStatus() == BluetoothManager.ConnectionStatus.CONNECTED && bluetoothManager.isDiscovered()) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finishAffinity();
            } else {
                Toast.makeText(getApplicationContext(), "Bluetooth not connected", Toast.LENGTH_SHORT).show();
            }
//            bluetoothManager.fire();
        });

        exitButton.setOnClickListener(view -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Do you want to exit?").setCancelable(false).
                    setPositiveButton("Yes", (dialogInterface, i) -> {
                        finish();
                        System.exit(0);
                    }).setNegativeButton("No", (dialogInterface, i) -> dialogInterface.cancel());
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        });

        if (allPermissionsGranted()) {
            init();
        } else {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        robot.hideTopBar();
    }

    private void init() {
        network.clean();
        bluetoothManager.clean();

        bluetoothManager.setFindDeviceCallback(new FindDeviceCallback() {
            @Override
            public void onFindDevice(String deviceName, BluetoothDevice newDevice) {
                if (deviceName.equals(robot.getNickName())) {
                    runOnUiThread(() ->
                            Toast.makeText(getApplicationContext(), "Bluetooth connecting...", Toast.LENGTH_SHORT).show());

                    bluetoothManager.stopScan();
                    bluetoothManager.connect(newDevice);
                }
            }
        });

        bluetoothManager.setGattCallback(new GattCallback() {
            @Override
            public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
                if (newState == BluetoothGatt.STATE_CONNECTED) {
                    runOnUiThread(() ->
                            Toast.makeText(getApplicationContext(), "Bluetooth connected", Toast.LENGTH_SHORT).show());
                } else {
                    runOnUiThread(() ->
                            Toast.makeText(getApplicationContext(), "Bluetooth disconnected", Toast.LENGTH_SHORT).show());
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finishAffinity();
//                    handler.postDelayed(() -> init(), 1000);
                }
            }

            @Override
            public void onServicesDiscovered(BluetoothGatt gatt, int status) {
                runOnUiThread(() ->
                        Toast.makeText(getApplicationContext(), "Bluetooth discovered", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
                runOnUiThread(() ->
                        Toast.makeText(getApplicationContext(), "Bluetooth subscribed", Toast.LENGTH_SHORT).show());
            }
        });

        Toast.makeText(this, "Bluetooth scan start", Toast.LENGTH_SHORT).show();
        bluetoothManager.startScan();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CODE_PERMISSIONS && 0 < grantResults.length) {
            if (allPermissionsGranted()) {
                init();
            } else {
                Toast.makeText(this, "Permissions not granted by the user.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
        }
    }

    private boolean allPermissionsGranted() {
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }

        return true;
    }
}