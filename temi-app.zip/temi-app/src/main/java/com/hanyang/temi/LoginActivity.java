package com.hanyang.temi;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.hanyang.temi.network.Network;
import com.hanyang.temi.network.WebSocketCallback;
import com.hanyang.temi.network.dto.WebSocketMessage;

public class LoginActivity extends AppCompatActivity {
    private TemiApplication temiApplication;
    private Network network;

    ImageButton loginButton, backButton;
    EditText nameTextBox, ipTextBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        temiApplication = (TemiApplication) getApplication();
        network = temiApplication.getNetwork();

        loginButton = (ImageButton) findViewById(R.id.loginButton);
        backButton = (ImageButton) findViewById(R.id.backButton);
        nameTextBox = (EditText) findViewById(R.id.nameTextBox);
        ipTextBox = (EditText) findViewById(R.id.ipTextBox);

        network.setControlSocketCallback(null);
        network.clean();

        backButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finishAffinity();
        });

        loginButton.setOnClickListener(view -> {
            String name = nameTextBox.getText().toString();
            String ip = ipTextBox.getText().toString();

            if (name.isEmpty() || ip.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Enter temi name and server ip", Toast.LENGTH_SHORT).show();
                return;
            }

            network.clean();
            network.connectServer(String.format("ws://%s:8888/ws", ip));
            network.setWebSocketCallback(new WebSocketCallback() {
                @Override
                public void onConnected() {
                    network.sendToServer("TEMI_INIT", name);
                }

                @Override
                public void onReceiveMessage(WebSocketMessage webSocketMessage) {
                    if (webSocketMessage.cmd.equals("TEMI_INIT_SUCCESS")) {
                        Intent intent = new Intent(getApplicationContext(), IdleActivity.class);
                        startActivity(intent);
                        finishAffinity();
                        runOnUiThread(() -> Toast.makeText(getApplicationContext(), "Connected", Toast.LENGTH_SHORT).show());
                    }
                }

                @Override
                public void onError() {
                    runOnUiThread(() -> Toast.makeText(getApplicationContext(), "Connection error", Toast.LENGTH_SHORT).show());
                }
            });
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
