package com.hanyang.temi.network;

public interface ControlSocketCallback {
    void onConnected();

    default void onCommandReceived(Integer cmd) {};

    default void onError() {};
}
