package com.hanyang.temi.control;

import com.robotemi.sdk.Robot;
import com.robotemi.sdk.navigation.model.SafetyLevel;

public class Control extends Thread {
    private ControlState controlState;
    private Robot robot;
    private float speed = 0.5f;
    private long delay = 100;
    private float headAngle = 0;
    private float headMovePerSec = 30;

    public Control() {
        controlState = new ControlState();

        robot = Robot.getInstance();
        robot.tiltAngle((int)headAngle);
        robot.setNavigationSafety(SafetyLevel.MEDIUM);
    }

    @Override
    public void run() {
        boolean stopWheel = false;
        boolean tempStopWheel;

        while (!Thread.currentThread().isInterrupted()) {
            tempStopWheel = false;

            if (controlState.forward) {
                robot.skidJoy(speed, 0, false);
            } else if (controlState.backward) {
                robot.skidJoy(-speed, 0, false);
            } else if (controlState.left) {
                robot.turnBy(180, speed);
            } else if (controlState.right) {
                robot.turnBy(-180, speed);
            } else {
                tempStopWheel = true;
                if (!stopWheel) {
                    robot.skidJoy(0, 0, false);
                }
            }
            stopWheel = tempStopWheel;

            if (controlState.up) {
                headAngle = Math.min(55, headAngle + (headMovePerSec * ((float)delay / 1000)));
                robot.tiltAngle((int)headAngle, 1);
            } else if (controlState.down) {
                headAngle = Math.max(-25, headAngle - (headMovePerSec * ((float)delay / 1000)));
                robot.tiltAngle((int)headAngle, 1);
            }

            try {
                Thread.sleep(delay);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void applyCommand(Integer cmd) {
        switch (cmd) {
            case 1:
                controlState.forward = true;
                break;
            case 2:
                controlState.backward = true;
                break;
            case 3:
                controlState.left = true;
                break;
            case 4:
                controlState.right = true;
                break;
            case 5:
                controlState.up = true;
                break;
            case 6:
                controlState.down = true;
                break;
            case -1:
                controlState.forward = false;
                break;
            case -2:
                controlState.backward = false;
                break;
            case -3:
                controlState.left = false;
                break;
            case -4:
                controlState.right = false;
                break;
            case -5:
                controlState.up = false;
                break;
            case -6:
                controlState.down = false;
                break;
            default:
                break;
        }
    }
}
