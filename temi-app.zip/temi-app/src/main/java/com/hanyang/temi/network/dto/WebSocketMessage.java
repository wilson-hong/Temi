package com.hanyang.temi.network.dto;

public class WebSocketMessage {
    public String cmd;
    public String data;

    public WebSocketMessage() {}

    public WebSocketMessage(String cmd, String data) {
        this.cmd = cmd;
        this.data = data;
    }
}