package com.hanyang.temi.bluetooth;

public interface HitCallback {
    default void onHit() {}
}
