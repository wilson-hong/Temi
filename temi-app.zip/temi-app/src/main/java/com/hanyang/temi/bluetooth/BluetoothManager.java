package com.hanyang.temi.bluetooth;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.ParcelUuid;
import android.util.Pair;

import androidx.core.app.ActivityCompat;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

@SuppressLint("MissingPermission")
public class BluetoothManager {
    private final UUID CHARACTERISTIC_CONFING_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private final UUID TARGET_CHARACTERISTIC_UUID = UUID.fromString("00000101-0000-1000-8000-00805f9b34fb");
    private final UUID LASER_CHARACTERISTIC_UUID = UUID.fromString("00000102-0000-1000-8000-00805f9b34fb");

    private BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    private BluetoothLeScanner bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();
    private Handler handler = new Handler();
    private List<Pair<String, BluetoothDevice>> deviceList = new LinkedList<>();
    private boolean scanning = false;
    private boolean discovered = false;
    private Context context;
    private FindDeviceCallback findDeviceCallback;
    private GattCallback gattCallback;
    private HitCallback hitCallback;
    private String targetServiceUuid;
    private BluetoothGatt connectedGatt;
    private BluetoothGattCharacteristic targetCharacteristic;
    private BluetoothGattCharacteristic laserCharacteristic;
    private int connectionStatus = ConnectionStatus.DISCONNECTED;

    public BluetoothManager(Context context) {
        this.context = context;
    }

    private boolean addBluetoothDevice(String deviceName, BluetoothDevice newDevice) {
        boolean exist = false;

        for (Pair<String, BluetoothDevice> item : deviceList) {
            if (item.second.getAddress().equals(newDevice.getAddress())) {
                exist = true;
                break;
            }
        }

        if (!exist) {
            deviceList.add(new Pair<>(deviceName, newDevice));
        }

        return !exist;
    }

    public void startScan() {
        scanning = true;
        bluetoothLeScanner.startScan(scanCallback);
    }

    public void stopScan() {
        if (scanning) {
            scanning = false;
            handler.removeCallbacksAndMessages(null);
            bluetoothLeScanner.stopScan(scanCallback);
        }
    }

    public void connect(BluetoothDevice device) {
        connectionStatus = ConnectionStatus.CONNECTING;
        device.connectGatt(context, false, bluetoothGattCallback);
    }

    private void subscribe(BluetoothGattDescriptor descriptor, int delay, int retry) {
        handler.postDelayed(() -> {
            if (!connectedGatt.writeDescriptor(descriptor)) {
                subscribe(descriptor, delay, retry - 1);
            }
        }, delay);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            List<ParcelUuid> serviceUuids = result.getScanRecord().getServiceUuids();

            if (serviceUuids != null) {
                String deviceName = result.getScanRecord().getDeviceName();
                BluetoothDevice newDevice = result.getDevice();

                if (targetServiceUuid != null && !serviceUuids.contains(targetServiceUuid)) {
                    boolean contains = false;
                    for (ParcelUuid uuid : serviceUuids) {
                        if (uuid.toString().equals(targetServiceUuid)) {
                            contains = true;
                            break;
                        }
                    }

                    if (!contains) {
                        return;
                    }
                }

                if (addBluetoothDevice(deviceName, newDevice)) {
                    if (findDeviceCallback != null) {
                        findDeviceCallback.onFindDevice(deviceName, newDevice);
                    }
                }
            }
        }
    };

    private final BluetoothGattCallback bluetoothGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);

            if (status == BluetoothGatt.GATT_SUCCESS) {
                if (newState == BluetoothGatt.STATE_CONNECTED) {
                    connectionStatus = ConnectionStatus.CONNECTED;
                    connectedGatt = gatt;
                    gatt.discoverServices();
                }
            } else {
                clean();
            }

            if (gattCallback != null) {
                gattCallback.onConnectionStateChange(gatt, status, newState);
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);

            if (status == BluetoothGatt.GATT_SUCCESS) {
                List<BluetoothGattService> services = gatt.getServices();
                for (BluetoothGattService service : services) {
                    for (BluetoothGattCharacteristic characteristic : service.getCharacteristics()) {

                        if (characteristic.getUuid().equals(LASER_CHARACTERISTIC_UUID)) {
                            laserCharacteristic = characteristic;
                        } else if (characteristic.getUuid().equals(TARGET_CHARACTERISTIC_UUID)) {
                            targetCharacteristic = characteristic;
                            gatt.setCharacteristicNotification(characteristic, true);
                            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(CHARACTERISTIC_CONFING_UUID);
                            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);

                            subscribe(descriptor, 500, 3);
                        }
                    }
                }
            }

            discovered = true;
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicRead(gatt, characteristic, status);

            if (gattCallback != null) {
                gattCallback.onCharacteristicRead(gatt, characteristic, status);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);

            if (gattCallback != null) {
                gattCallback.onCharacteristicChanged(gatt, characteristic);
            }

            if (hitCallback != null && characteristic.getUuid().equals(TARGET_CHARACTERISTIC_UUID)) {
                ByteBuffer bb = ByteBuffer.wrap(characteristic.getValue());
                bb.order(ByteOrder.LITTLE_ENDIAN);
                if (bb.getShort() != 0) {
                    hitCallback.onHit();
                }
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);

            if (gattCallback != null) {
                gattCallback.onDescriptorWrite(gatt, descriptor, status);
            }
        }
    };

    public void setFindDeviceCallback(FindDeviceCallback findDeviceCallback) {
        this.findDeviceCallback = findDeviceCallback;
    }

    public void setGattCallback(GattCallback gattCallback) {
        this.gattCallback = gattCallback;
    }

    public void setTargetServiceUuid(String targetServiceUuid) {
        this.targetServiceUuid = targetServiceUuid;
    }

    public void setHitCallback(HitCallback hitCallback) {
        this.hitCallback = hitCallback;
    }

    public int getConnectionStatus() {
        return connectionStatus;
    }

    public boolean isDiscovered() {
        return discovered;
    }

    public void fire() {
        if (connectionStatus == ConnectionStatus.CONNECTED && discovered) {
            ByteBuffer bb = ByteBuffer.allocate(2);
            bb.order(ByteOrder.LITTLE_ENDIAN);
            bb.putShort((short) 1);

            byte[] bytes = bb.array();
            laserCharacteristic.setValue(bytes);
            connectedGatt.writeCharacteristic(laserCharacteristic);
        }
    }

    public void clean() {
        if (scanning) {
            bluetoothLeScanner.stopScan(scanCallback);
        }

        if (connectedGatt != null) {
            connectedGatt.disconnect();
            connectedGatt.close();
            connectedGatt = null;
        }

        targetCharacteristic = null;
        laserCharacteristic = null;
        discovered = false;
        deviceList.clear();
        connectionStatus = ConnectionStatus.DISCONNECTED;

    }

    public static final class ConnectionStatus {
        public static final int DISCONNECTED = 0;
        public static final int CONNECTED = 1;
        public static final int CONNECTING = 2;
    }
}
