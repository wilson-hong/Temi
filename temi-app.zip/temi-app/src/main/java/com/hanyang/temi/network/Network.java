package com.hanyang.temi.network;

import static java.lang.Thread.State.TERMINATED;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.util.Log;

import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Network {
    private static final int CONTROL_PORT = 4040;
    private static final int VIDEO_PORT = 5050;

    public static final int IPTOS_THROUGHPUT = 0x08;
    public static final int IPTOS_LOWDELAY = 0x10;
    public static final int STATUS_DISCONNECTED = 0;
    public static final int STATUS_CONNECTED = 1;

    private URI serverUri;

    private WebClient webClient;
    private VideoThread videoThread;
    private ControlThread controlThread;
    private WebSocketCallback webSocketCallback;
    private ControlSocketCallback controlSocketCallback;
    private VideoSocketCallback videoSocketCallback;

    public Network() {}

    public void connectServer(String uri) {
        try {
            serverUri = new URI(uri);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        webClient = new WebClient(serverUri);
        webClient.connect();
    }

    public void start() {
        controlThread = new ControlThread(CONTROL_PORT);
        videoThread = new VideoThread(VIDEO_PORT);
        controlThread.start();
        videoThread.start();
    }

    public void setWebSocketCallback(WebSocketCallback webSocketCallback) {
        this.webSocketCallback = webSocketCallback;
        if (webClient != null) {
            webClient.setWebSocketCallback(webSocketCallback);
        }
    }

    public void setControlSocketCallback(ControlSocketCallback controlSocketCallback) {
        this.controlSocketCallback = controlSocketCallback;
        if (controlThread != null) {
            controlThread.setControlSocketCallback(controlSocketCallback);
        }
    }

    public void setVideoSocketCallback(VideoSocketCallback videoSocketCallback) {
        this.videoSocketCallback = videoSocketCallback;
        if (videoThread != null) {
            videoThread.setVideoSocketCallback(videoSocketCallback);
        }
    }

    public void sendToServer(String cmd, String data) {
        if (webClient != null) {
            webClient.send(cmd, data);
        }
    }

    public void pushEncodedData(EncodedData data) {
        if (videoThread != null) {
            videoThread.pushEncodedData(data);
        }
    }

    public int getServerStatus() {
        return webClient != null && webClient.isOpen() ? STATUS_CONNECTED : STATUS_DISCONNECTED;
    }

    public int getControlStatus() {
        return controlThread != null && controlThread.getState() != TERMINATED ? controlThread.getStatus() : STATUS_DISCONNECTED;
    }

    public int getVideoStatus() {
        return videoThread != null && videoThread.getState() != TERMINATED ? videoThread.getStatus() : STATUS_DISCONNECTED;
    }

    public UUID getPlayerUUID() {
        return controlThread != null ? controlThread.getPlayerUUID() : null;
    }

    public void clean() {
        cleanPlayer();
        cleanServer();
    }

    public void cleanPlayer() {
        if (controlThread != null) {
            controlThread.clean();
            controlThread.interrupt();
        }

        if (videoThread != null) {
            videoThread.clean();
            videoThread.interrupt();
        }
    }

    public void cleanServer() {
        if (webClient != null) {
            webClient.close();
            webClient = null;
        }
    }
}
