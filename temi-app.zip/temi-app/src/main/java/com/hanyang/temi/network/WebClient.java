package com.hanyang.temi.network;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hanyang.temi.network.dto.WebSocketMessage;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.drafts.Draft;
import org.java_websocket.handshake.ServerHandshake;

import java.io.IOException;
import java.net.URI;
import java.nio.ByteBuffer;

public class WebClient extends WebSocketClient {
    private WebSocketCallback webSocketCallback;
    private ObjectMapper objectMapper = new ObjectMapper();;

    public WebClient(URI serverUri, Draft draft) {
        super(serverUri, draft);
    }

    public WebClient(URI serverURI) { super(serverURI); }

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        System.out.println("new connection opened");
        if (webSocketCallback != null) {
            webSocketCallback.onConnected();
        }
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        System.out.println("closed with exit code " + code + " additional info: " + reason);
        if (webSocketCallback != null) {
            webSocketCallback.onDisonnected();
        }
    }

    @Override
    public void onMessage(String message) {
        System.out.println("received message: " + message);
        if (webSocketCallback != null) {
            WebSocketMessage msg = null;
            try {
                msg = objectMapper.readValue(message, WebSocketMessage.class);
            } catch (IOException e) {
                e.printStackTrace();
            }

            if (msg != null) {
                webSocketCallback.onReceiveMessage(msg);
            }
        }
    }

    @Override
    public void onMessage(ByteBuffer message) {
        System.out.println("received ByteBuffer");
    }

    @Override
    public void onError(Exception ex) {
        System.err.println("an error occurred:" + ex);
        if (webSocketCallback != null) {
            webSocketCallback.onError();
        }
    }

    public void setWebSocketCallback(WebSocketCallback webSocketCallback) {
        this.webSocketCallback = webSocketCallback;
    }

    public void send(String cmd, String data) {
        if (!isOpen()) {
            return;
        }

        String text = null;
        try {
            text = objectMapper.writeValueAsString(new WebSocketMessage(cmd, data));
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        send(text);
    }

    public void send(WebSocketMessage webSocketMessage) {
        if (!isOpen()) {
            return;
        }

        String text = null;
        try {
            text = objectMapper.writeValueAsString(webSocketMessage);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        send(text);
    }
}