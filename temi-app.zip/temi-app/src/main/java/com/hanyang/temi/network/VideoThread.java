package com.hanyang.temi.network;

import static com.hanyang.temi.network.Network.IPTOS_LOWDELAY;
import static com.hanyang.temi.network.Network.IPTOS_THROUGHPUT;
import static com.hanyang.temi.network.Network.STATUS_CONNECTED;
import static com.hanyang.temi.network.Network.STATUS_DISCONNECTED;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class VideoThread extends Thread{
    private ServerSocket videoServerSocket;
    private Socket videoSocket;
    private VideoSocketCallback videoSocketCallback;
    private int status = STATUS_DISCONNECTED;
    private Queue<EncodedData> encodedDataQueue = new ConcurrentLinkedQueue<>();

    public VideoThread(int port) {
        try {
            videoServerSocket = new ServerSocket(port);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setVideoSocketCallback(VideoSocketCallback videoSocketCallback) {
        this.videoSocketCallback = videoSocketCallback;
    }

    public void pushEncodedData(EncodedData data) {
        encodedDataQueue.offer(data);
    }

    public int getStatus() {
        return status;
    }

    @Override
    public void run() {
        EncodedData data;
        OutputStream outputStream;
        DataOutputStream dataOutputStream;

        try {
            videoSocket = videoServerSocket.accept();;
            videoSocket.setTcpNoDelay(true);
            videoSocket.setTrafficClass(IPTOS_THROUGHPUT | IPTOS_LOWDELAY);

            outputStream = videoSocket.getOutputStream();
            dataOutputStream = new DataOutputStream(outputStream);
        } catch (IOException e) {
            e.printStackTrace();
            status = STATUS_DISCONNECTED;
            if (videoSocketCallback != null) {
                videoSocketCallback.onError();
            }
            return;
        }

        status = STATUS_CONNECTED;
        if (videoSocketCallback != null) {
            videoSocketCallback.onConnected();
        }

        while (!Thread.currentThread().isInterrupted()) {
            data = encodedDataQueue.poll();
            if (data != null) {
                try {
                    dataOutputStream.writeInt(data.bytes.length + Long.BYTES);
                    dataOutputStream.writeLong(data.timeUs);
                    dataOutputStream.write(data.bytes);
                } catch (IOException e) {
                    if (videoSocketCallback != null) {
                        videoSocketCallback.onError();
                    }
                    e.printStackTrace();
                    break;
                }
            }
        }

        status = STATUS_DISCONNECTED;
        clean();
    }

    public void clean() {
        if (videoServerSocket != null) {
            try {
                videoServerSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            videoServerSocket = null;
        }

        if (videoSocket != null) {
            try {
                videoSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            videoSocket = null;
        }
    }
}
