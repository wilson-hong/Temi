package com.hanyang.temi;

import static android.hardware.camera2.CameraMetadata.LENS_FACING_BACK;

import static java.lang.System.currentTimeMillis;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.Surface;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.hanyang.temi.bluetooth.BluetoothManager;
import com.hanyang.temi.bluetooth.HitCallback;
import com.hanyang.temi.camera.Camera;
import com.hanyang.temi.control.Control;
import com.hanyang.temi.encoder.Encoder;
import com.hanyang.temi.network.ControlSocketCallback;
import com.hanyang.temi.network.Network;
import com.hanyang.temi.network.VideoSocketCallback;
import com.hanyang.temi.network.WebSocketCallback;
import com.hanyang.temi.network.dto.WebSocketMessage;
import com.robotemi.sdk.Robot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GameActivity extends AppCompatActivity {
    private TemiApplication temiApplication;
    private BluetoothManager bluetoothManager;
    private Network network;

    private Camera camera;
    private Encoder encoder;
    private Control control;
    private WifiManager wifiManager;
    private WifiManager.WifiLock wifiLock;

    private ImageView imageView;
    private ImageButton backButton;
    private List<Boolean> gameState = Arrays.asList(false, true); // started, alive
    private long fireTime = 0;
    private long fireDelay = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        temiApplication = (TemiApplication) getApplication();
        bluetoothManager = temiApplication.getBluetoothManager();
        network = temiApplication.getNetwork();

        imageView = (ImageView)findViewById(R.id.imageView);
        backButton = (ImageButton) findViewById(R.id.backButton);

        control = new Control();
        control.start();

        encoder = new Encoder();

        camera = new Camera(this);

        encoder.setEncoderCallback(data -> network.pushEncodedData(data));

        network.setWebSocketCallback(new WebSocketCallback() {
            @Override
            public void onConnected() {}

            @Override
            public void onReceiveMessage(WebSocketMessage webSocketMessage) {
                if (webSocketMessage.cmd.equals("GAME_START")) {
                    gameState.set(0, true);
                    gameState.set(1, true);
                } else if (webSocketMessage.cmd.equals("GAME_END")) {
                    gameState.set(0, false);
                    gameState.set(1, true);
                    runOnUiThread(() -> Glide.with(getApplicationContext()).load(R.drawable.face_none).into(imageView));
                }
            }

            @Override
            public void onDisonnected() {
                network.setControlSocketCallback(null);
                network.setVideoSocketCallback(null);

                runOnUiThread(() -> Toast.makeText(getApplicationContext(), "Server Disconnected", Toast.LENGTH_SHORT).show());
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finishAffinity();
            }
        });

        bluetoothManager.setHitCallback(new HitCallback() {
            @Override
            public void onHit() {
                if (gameState.get(1)) {
                    runOnUiThread(() -> Glide.with(getApplicationContext()).load(R.drawable.face_dead).into(imageView));
                    network.sendToServer("TEMI_HIT", "");
                    gameState.set(1, false);

                    camera.clean();
                    encoder.clean();
                }
            }
        });

        network.setControlSocketCallback(new ControlSocketCallback() {
            @Override
            public void onConnected() {}

            @Override
            public void onError() {
                network.sendToServer("PLAYER_DISCONNECTED", "");
                network.setControlSocketCallback(null);
                network.setVideoSocketCallback(null);

                Intent intent = new Intent(getApplicationContext(), IdleActivity.class);
                startActivity(intent);
                finishAffinity();
            }

            @Override
            public void onCommandReceived(Integer cmd) {

                switch (cmd) {
                    case 7:
                        if (fireDelay < currentTimeMillis() - fireTime) {
                            bluetoothManager.fire();
                            fireTime = currentTimeMillis();
                        }
                        break;
                    case 1001:
                        if (network.getVideoStatus() == Network.STATUS_CONNECTED) {
                            camera.clean();
                            openCamera();
                            encoder.start();

                            List<Surface> outputSurfaces = new ArrayList<>();
                            outputSurfaces.add(encoder.getInputSurface());
                            try {
                                camera.startCapture(outputSurfaces);
                            } catch (CameraAccessException e) {
                                e.printStackTrace();
                            }
                        }
                        break;
                    case -1001:
                        camera.clean();
                        encoder.clean();
                        break;
                    case 1010:
                        runOnUiThread(() -> Glide.with(getApplicationContext()).load(R.drawable.face_none).into(imageView));
                        break;
                    case 1011:
                        runOnUiThread(() -> Glide.with(getApplicationContext()).load(R.drawable.face_red_live).into(imageView));
                        break;
                    case 1012:
                        runOnUiThread(() -> Glide.with(getApplicationContext()).load(R.drawable.face_blue_live).into(imageView));
                        break;
                    default:
                        if (gameState.get(0) && gameState.get(1)) {
                            control.applyCommand(cmd);
                        }
                        break;
                }

                Log.d("D", "Control - onCommandReceived: " + cmd);
            }
        });

        network.setVideoSocketCallback(new VideoSocketCallback() {
            @Override
            public void onConnected() {}

            @Override
            public void onError() {
                network.sendToServer("PLAYER_DISCONNECTED", "");
                network.setControlSocketCallback(null);
                network.setVideoSocketCallback(null);

                Intent intent = new Intent(getApplicationContext(), IdleActivity.class);
                startActivity(intent);
                finishAffinity();
            }
        });

        backButton.setOnClickListener(view -> {
            network.sendToServer("PLAYER_DISCONNECTED", "");
            network.setControlSocketCallback(null);
            network.setVideoSocketCallback(null);

            Intent intent = new Intent(getApplicationContext(), IdleActivity.class);
            startActivity(intent);
            finishAffinity();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        lockWifi();
        openCamera();
    }

    @Override
    protected void onPause() {
        super.onPause();

//        releaseWifi();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

//        releaseWifi();

        if (camera != null) {
            camera.clean();
            camera = null;
        }

        if (encoder != null) {
            encoder.clean();
            encoder = null;
        }

        if (control != null) {
            control.interrupt();
            control = null;
        }
    }

    private void lockWifi() {
        wifiManager = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiLock = wifiManager.createWifiLock((Build.VERSION.SDK_INT >= 29) ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF, null);
        wifiLock.setReferenceCounted(true);
        wifiLock.acquire();
    }

    private void releaseWifi() {
        if (wifiLock != null) {
            wifiLock.release();
            wifiLock = null;
        }
    }

    private void openCamera() {
        if (camera != null) {
            try {
                camera.open(LENS_FACING_BACK, 1920, 1080);
            } catch (CameraAccessException e) {
                e.printStackTrace();
            }
        }
    }
}
