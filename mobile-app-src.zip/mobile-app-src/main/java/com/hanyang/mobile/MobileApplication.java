package com.hanyang.mobile;

import android.app.Application;
import android.util.Pair;

import com.hanyang.mobile.network.Network;

public class MobileApplication extends Application {
    private Network network = new Network();

    public Network getNetwork() {
        return network;
    }

    public void setNetwork(Network network) {
        this.network = network;
    }
}

