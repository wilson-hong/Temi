package com.hanyang.mobile;

import static com.hanyang.mobile.network.Network.STATUS_CONNECTED;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hanyang.mobile.entity.Temi;
import com.hanyang.mobile.network.ControlSocketCallback;
import com.hanyang.mobile.network.Network;
import com.hanyang.mobile.network.WebSocketCallback;
import com.hanyang.mobile.network.dto.WebSocketMessage;
import com.hanyang.mobile.ui.TemiListViewAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ConnectTemiActivity extends AppCompatActivity {
    private MobileApplication mobileApplication;
    private Network network;
    private ObjectMapper objectMapper;

    ImageButton nextButton, backButton;
    ListView temiListView;
    TemiListViewAdapter adapter;

    List<Temi> temis = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect_temi);
        mobileApplication = (MobileApplication) getApplication();
        network = mobileApplication.getNetwork();
        objectMapper = new ObjectMapper();

        nextButton = (ImageButton) findViewById(R.id.nextButton);
        backButton = (ImageButton) findViewById(R.id.backButton);
        temiListView = (ListView) findViewById(R.id.temiListView);

        adapter = new TemiListViewAdapter(this, temis);
        temiListView.setAdapter(adapter);

        network.setWebSocketCallback(new WebSocketCallback() {
            @Override
            public void onConnected() {}

            @Override
            public void onDisonnected() {
                runOnUiThread(() -> Toast.makeText(getApplicationContext(), "Server Disconnected", Toast.LENGTH_SHORT).show());
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finishAffinity();
            }

            @Override
            public void onReceiveMessage(WebSocketMessage webSocketMessage) {
                if (webSocketMessage.cmd.equals("TEMI_LIST")) {
                    try {
                        temis = objectMapper.readValue(webSocketMessage.data, new TypeReference<List<Temi>>() {});
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }

                    runOnUiThread(() -> {
                        adapter.clear();
                        adapter.addAll(temis);
                    });
                } else if (webSocketMessage.cmd.equals("TEMI_STATE_CHANGED")) {
                    Temi temi = null;
                    try {
                        temi = objectMapper.readValue(webSocketMessage.data, Temi.class);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }

                    UUID uuid = temi.getUuid();
                    Temi target = temis.stream()
                            .filter(x -> x.getUuid().equals(uuid))
                            .findAny()
                            .orElse(null);

                    if (target != null) {
                        target.setState(temi.getState());
                        runOnUiThread(() -> adapter.notifyDataSetChanged());
                    }
                }
            }
        });

        network.setControlSocketCallback(new ControlSocketCallback() {
            @Override
            public void onConnected() {
//                runOnUiThread(() -> nextButton.callOnClick());
            }

            @Override
            public void onError() {
                Intent intent = new Intent(getApplicationContext(), ConnectTemiActivity.class);
                startActivity(intent);
                finishAffinity();
            }
        });

        backButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(intent);
            finishAffinity();
        });

        nextButton.setOnClickListener(view -> {
            if (network.getControlStatus() == STATUS_CONNECTED && network.getVideoStatus() == STATUS_CONNECTED) {
                Intent intent = new Intent(getApplicationContext(), WaitingRoomActivity.class);
                startActivity(intent);
                finishAffinity();
            } else {
                Toast.makeText(getApplicationContext(), "Temi not connected", Toast.LENGTH_SHORT).show();
            }
        });

        network.sendToServer("GET_TEMI_LIST", "");
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
