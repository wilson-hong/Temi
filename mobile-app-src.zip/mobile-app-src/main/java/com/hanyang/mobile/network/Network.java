package com.hanyang.mobile.network;


import static java.lang.Thread.State.TERMINATED;

import android.os.Looper;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.util.UUID;


public class Network {
    private static final int CONTROL_PORT = 4040;
    private static final int VIDEO_PORT = 5050;

    public static final int IPTOS_THROUGHPUT = 0x08;
    public static final int IPTOS_LOWDELAY = 0x10;
    public static final int STATUS_DISCONNECTED = 0;
    public static final int STATUS_CONNECTED = 1;

    private URI serverUri;
    private InetAddress temiAddress;
    private UUID playerUUID;

    private WebClient webClient;
    private VideoThread videoThread;
    private ControlThread controlThread;
    private WebSocketCallback webSocketCallback;
    private ControlSocketCallback controlSocketCallback;
    private VideoSocketCallback videoSocketCallback;

    public Network() {}


    public void connectServer(String uri) {
        try {
            serverUri = new URI(uri);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        webClient = new WebClient(serverUri);
        webClient.connect();
    }

    public void connectTemi(InetAddress address) {
        if (controlThread != null || videoThread != null) {
            return;
        }

        temiAddress = address;

        controlThread = new ControlThread(temiAddress, CONTROL_PORT, playerUUID);
        videoThread = new VideoThread(temiAddress, VIDEO_PORT);

        if (controlSocketCallback != null) {
            controlThread.setControlSocketCallback(controlSocketCallback);
        }
        if (videoSocketCallback != null) {
            videoThread.setVideoSocketCallback(videoSocketCallback);
        }

        controlThread.start();
        videoThread.start();
    }

    public void connectTemi(String address) {
        if (controlThread != null || videoThread != null) {
            return;
        }

        if (Looper.getMainLooper().isCurrentThread()) {
            new Thread(() -> {
                try {
                    temiAddress = InetAddress.getByName(address);
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                }
                connectTemi(temiAddress);
            }).start();
        } else {
            try {
                temiAddress = InetAddress.getByName(address);
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }
            connectTemi(temiAddress);
        }
    }

    public void setWebSocketCallback(WebSocketCallback webSocketCallback) {
        this.webSocketCallback = webSocketCallback;
        if (webClient != null) {
            webClient.setWebSocketCallback(webSocketCallback);
        }
    }

    public void setControlSocketCallback(ControlSocketCallback controlSocketCallback) {
        this.controlSocketCallback = controlSocketCallback;
        if (controlThread != null) {
            controlThread.setControlSocketCallback(controlSocketCallback);
        }
    }

    public void setVideoSocketCallback(VideoSocketCallback videoSocketCallback) {
        this.videoSocketCallback = videoSocketCallback;
        if (videoThread != null) {
            videoThread.setVideoSocketCallback(videoSocketCallback);
        }
    }

    public void sendToServer(String cmd, String data) {
        if (webClient != null) {
            webClient.send(cmd, data);
        }
    }

    public void pushCommand(Integer cmd) {
        if (controlThread != null) {
            controlThread.pushCommand(cmd);
        }
    }

    public int getServerStatus() {
        return webClient != null && webClient.isOpen() ? STATUS_CONNECTED : STATUS_DISCONNECTED;
    }

    public int getControlStatus() {
        return controlThread != null && controlThread.getState() != TERMINATED ? controlThread.getStatus() : STATUS_DISCONNECTED;
    }

    public int getVideoStatus() {
        return videoThread != null && videoThread.getState() != TERMINATED ? videoThread.getStatus() : STATUS_DISCONNECTED;
    }

    public UUID getPlayerUUID() {
        return playerUUID;
    }

    public void setPlayerUUID(UUID playerUUID) {
        this.playerUUID = playerUUID;
    }

    public void clean() {
        cleanTemi();
        cleanServer();
    }

    public void cleanTemi() {
        if (controlThread != null) {
            controlThread.clean();
            controlThread.interrupt();
            controlThread = null;
        }

        if (videoThread != null) {
            videoThread.clean();
            videoThread.interrupt();
            videoThread = null;
        }
    }

    public void cleanServer() {
        if (webClient != null) {
            webClient.close();
            webClient = null;
        }
    }
}