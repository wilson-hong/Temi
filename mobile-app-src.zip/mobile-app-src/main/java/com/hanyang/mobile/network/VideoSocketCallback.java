package com.hanyang.mobile.network;

public interface VideoSocketCallback {
    void onConnected();

    void onReceiveData(EncodedData data);

    default void onError() {};
}
