package com.hanyang.mobile.network;


public class EncodedData {
    public byte[] bytes;
    public long timeUs;

    public EncodedData(byte[] bytes, long timeUs) {
        this.bytes = bytes;
        this.timeUs = timeUs;
    }
}