package com.hanyang.mobile.network;


import static com.hanyang.mobile.network.Network.IPTOS_LOWDELAY;
import static com.hanyang.mobile.network.Network.IPTOS_THROUGHPUT;
import static com.hanyang.mobile.network.Network.STATUS_CONNECTED;
import static com.hanyang.mobile.network.Network.STATUS_DISCONNECTED;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

public class ControlThread extends Thread{
    private Socket controlSocket;
    private ControlSocketCallback controlSocketCallback;
    private int status = STATUS_DISCONNECTED;
    private Queue<Integer> commandQueue = new ConcurrentLinkedQueue<>();
    InetAddress address;
    int port;
    private UUID playerUUID;


    public ControlThread(InetAddress address, int port, UUID playerUUID) {
        this.address = address;
        this.port = port;
        this.playerUUID = playerUUID;
    }

    public void setControlSocketCallback(ControlSocketCallback controlSocketCallback) {
        this.controlSocketCallback = controlSocketCallback;
    }

    public void pushCommand(Integer cmd) {
        commandQueue.offer(cmd);
    }

    public int getStatus() {
        return status;
    }

    @Override
    public void run() {
        OutputStream outputStream;
        DataOutputStream dataOutputStream = null;
        Integer cmd;

        try {
            controlSocket = new Socket(address, port);
            controlSocket.setTcpNoDelay(true);
            controlSocket.setTrafficClass(IPTOS_THROUGHPUT | IPTOS_LOWDELAY);

            outputStream = controlSocket.getOutputStream();
            dataOutputStream = new DataOutputStream(outputStream);
        } catch (IOException e) {
            if (controlSocketCallback != null) {
                controlSocketCallback.onError();
            }
            e.printStackTrace();
            return;
        }

        try {
            dataOutputStream.writeLong(playerUUID.getMostSignificantBits());
            dataOutputStream.writeLong(playerUUID.getLeastSignificantBits());
            dataOutputStream.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

        status = STATUS_CONNECTED;
        if (controlSocketCallback != null) {
            controlSocketCallback.onConnected();
        }


        while (!Thread.currentThread().isInterrupted()) {
            cmd = commandQueue.poll();
            if (cmd != null) {
                try {
                    dataOutputStream.writeInt(cmd);
                    dataOutputStream.flush();
                } catch (IOException e) {
                    if (controlSocketCallback != null) {
                        controlSocketCallback.onError();
                    }
                    e.printStackTrace();
                    break;
                }
            }
        }

        status = STATUS_DISCONNECTED;
        clean();
    }

    public void clean() {
        if (controlSocket != null) {
            try {
                controlSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            controlSocket = null;
        }
    }
}
