package com.hanyang.mobile.network;

public interface ControlSocketCallback {
    void onConnected();

    default void onError() {};
}
