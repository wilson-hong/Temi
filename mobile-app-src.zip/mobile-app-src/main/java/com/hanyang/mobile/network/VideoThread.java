package com.hanyang.mobile.network;


import static com.hanyang.mobile.network.Network.IPTOS_LOWDELAY;
import static com.hanyang.mobile.network.Network.IPTOS_THROUGHPUT;
import static com.hanyang.mobile.network.Network.STATUS_CONNECTED;
import static com.hanyang.mobile.network.Network.STATUS_DISCONNECTED;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class VideoThread extends Thread{
    private Socket videoSocket;
    private VideoSocketCallback videoSocketCallback;
    private int status = STATUS_DISCONNECTED;
    private Queue<EncodedData> encodedDataQueue = new ConcurrentLinkedQueue<>();
    InetAddress address;
    int port;

    public VideoThread(InetAddress address, int port) {
        this.address = address;
        this.port = port;
    }

    public void setVideoSocketCallback(VideoSocketCallback videoSocketCallback) {
        this.videoSocketCallback = videoSocketCallback;
    }

    public int getStatus() {
        return status;
    }

    @Override
    public void run() {
        InputStream inputStream;
        DataInputStream dataInputStream = null;

        try {
            videoSocket = new Socket(address, port);
            videoSocket.setTcpNoDelay(true);
            videoSocket.setTrafficClass(IPTOS_THROUGHPUT | IPTOS_LOWDELAY);
            inputStream = videoSocket.getInputStream();
            dataInputStream = new DataInputStream(inputStream);
        } catch (IOException e) {
            if (videoSocketCallback != null) {
                videoSocketCallback.onError();
            }
            e.printStackTrace();
            return;
        }

        status = STATUS_CONNECTED;
        if (videoSocketCallback != null) {
            videoSocketCallback.onConnected();
        }

        int paketSize;
        long timeUs = 0;
        byte[] dataBytes = null;
        while (!Thread.currentThread().isInterrupted()) {
            try {
                paketSize = dataInputStream.readInt();
                timeUs = dataInputStream.readLong();
                dataBytes = new byte[paketSize - Long.BYTES];
                dataInputStream.readFully(dataBytes);
            } catch (IOException e) {
                if (videoSocketCallback != null) {
                    videoSocketCallback.onError();
                }
                e.printStackTrace();
                break;
            }

            if (videoSocketCallback != null) {
                videoSocketCallback.onReceiveData(new EncodedData(dataBytes, timeUs));
            }
        }

        status = STATUS_DISCONNECTED;
        clean();
    }

    public void clean() {
        if (videoSocket != null) {
            try {
                videoSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            videoSocket = null;
        }
    }
}
