package com.hanyang.mobile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hanyang.mobile.entity.Player;
import com.hanyang.mobile.entity.Temi;
import com.hanyang.mobile.network.Network;
import com.hanyang.mobile.network.WebSocketCallback;
import com.hanyang.mobile.network.dto.WebSocketMessage;

import java.util.UUID;

public class LoginActivity extends AppCompatActivity {
    private MobileApplication mobileApplication;
    private Network network;
    private ObjectMapper objectMapper;

    ImageButton loginButton, backButton;
    EditText nameTextBox, ipTextBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mobileApplication = (MobileApplication) getApplication();
        network = mobileApplication.getNetwork();
        objectMapper = new ObjectMapper();

        loginButton = (ImageButton) findViewById(R.id.loginButton);
        backButton = (ImageButton) findViewById(R.id.backButton);
        nameTextBox = (EditText) findViewById(R.id.nameTextBox);
        ipTextBox = (EditText) findViewById(R.id.ipTextBox);

        network.clean();

        backButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finishAffinity();
        });

        loginButton.setOnClickListener(view -> {
            String name = nameTextBox.getText().toString();
            String ip = ipTextBox.getText().toString();

            if (name.isEmpty() || ip.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Enter player name and server ip", Toast.LENGTH_SHORT).show();
                return;
            }

            network.clean();
            network.connectServer(String.format("ws://%s:8888/ws", ip));
            network.setWebSocketCallback(new WebSocketCallback() {
                @Override
                public void onConnected() {
                    network.sendToServer("PLAYER_INIT", name);
                }

                @Override
                public void onReceiveMessage(WebSocketMessage webSocketMessage) {
                    if (webSocketMessage.cmd.equals("PLAYER_INIT_SUCCESS")) {
                        Player player = null;
                        try {
                            player = objectMapper.readValue(webSocketMessage.data, Player.class);
                        } catch (JsonProcessingException e) {
                            e.printStackTrace();
                        }
                        UUID uuid = player.getUuid();
                        network.setPlayerUUID(uuid);

                        Intent intent = new Intent(LoginActivity.this, ConnectTemiActivity.class);
                        startActivity(intent);
                        finishAffinity();
                    } else if (webSocketMessage.cmd.equals("PLAYER_INIT_FAILED")) {
                        runOnUiThread(() -> Toast.makeText(getApplicationContext(), "No empty slots (max players: 4)", Toast.LENGTH_SHORT).show());
                    }
                }

                @Override
                public void onError() {
                    runOnUiThread(() -> Toast.makeText(getApplicationContext(), "Connection error", Toast.LENGTH_SHORT).show());
                }
            });
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
