package com.hanyang.mobile.decoder;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.view.Surface;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.hanyang.mobile.network.EncodedData;
import com.hanyang.mobile.network.Network;
import com.hanyang.mobile.network.VideoSocketCallback;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

class InputBufferPair {
    public InputBufferPair(int idx, ByteBuffer buffer) {
        this.idx = idx;
        this.buffer = buffer;
    }

    int idx;
    ByteBuffer buffer;
}

public class Decoder extends Thread {
    private MediaCodec codec;
    private Surface output;
    private Queue<InputBufferPair> inputBufferQueue = new ConcurrentLinkedQueue<>();
    private Queue<EncodedData> encodedDataQueue = new ConcurrentLinkedQueue<>();

    public Decoder(Surface output) {
        this.output = output;
    }

    @Override
    public void run() {
        long timeUs = -1;

        initCodec();

        if (codec != null) {
            codec.start();
        }

        while (!Thread.currentThread().isInterrupted()) {
            if (!inputBufferQueue.isEmpty() && !encodedDataQueue.isEmpty()) {
                EncodedData data = encodedDataQueue.poll();

                if (timeUs != data.timeUs && timeUs != -1) {
                    InputBufferPair pair = inputBufferQueue.poll();
                    codec.queueInputBuffer(pair.idx, 0, pair.buffer.position(), timeUs, 0);
                }

                InputBufferPair pair = inputBufferQueue.peek();
                if (pair != null) {
                    pair.buffer.put(data.bytes);
                }

                timeUs = data.timeUs;
            }
        }

        clean();
    }

    public void pushEncodedData(EncodedData data) {
        encodedDataQueue.offer(data);
    }

    private void initCodec() {
        MediaFormat videoFormat = getVideoFormat();
        String decoderCodecName = new MediaCodecList(MediaCodecList.REGULAR_CODECS).findDecoderForFormat(videoFormat);
        if (decoderCodecName.isEmpty()) {
            Toast.makeText(null, "Codec not found.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            codec = MediaCodec.createByCodecName(decoderCodecName);
        } catch (IOException e) {
            e.printStackTrace();
        }
        codec.configure(videoFormat, output, null, 0);

        codec.setCallback(new MediaCodec.Callback() {
            @Override
            public void onInputBufferAvailable(@NonNull MediaCodec codec, int index) {
                inputBufferQueue.offer(new InputBufferPair(index, codec.getInputBuffer(index)));
            }

            @Override
            public void onOutputBufferAvailable(@NonNull MediaCodec codec, int index, @NonNull MediaCodec.BufferInfo info) {
                try {
                    codec.releaseOutputBuffer(index, true);
                } catch (MediaCodec.CodecException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(@NonNull MediaCodec codec, @NonNull MediaCodec.CodecException e) {
            }

            @Override
            public void onOutputFormatChanged(@NonNull MediaCodec codec, @NonNull MediaFormat format) {
            }
        });
    }

    private MediaFormat getVideoFormat() {
        MediaFormat videoFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, 1280, 720);
        videoFormat.setInteger(MediaFormat.KEY_BIT_RATE, 8000000);
        videoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
        videoFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface); //COLOR_FormatYUV420Planar, COLOR_FormatSurface, COLOR_FormatYUV420Flexible
        videoFormat.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);

        return videoFormat;
    }

    private void clean() {
        if (codec != null) {
            codec.stop();
            codec.release();
            codec = null;
        }
    }
}
