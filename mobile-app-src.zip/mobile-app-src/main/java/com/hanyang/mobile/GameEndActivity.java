package com.hanyang.mobile;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Size;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.hanyang.mobile.decoder.Decoder;
import com.hanyang.mobile.network.EncodedData;
import com.hanyang.mobile.network.Network;
import com.hanyang.mobile.network.VideoSocketCallback;

public class GameEndActivity extends AppCompatActivity {
    private TextView resultTextview;
    private ImageButton nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_end);

        resultTextview = (TextView) findViewById(R.id.resultTextview);
        nextButton = (ImageButton) findViewById(R.id.nextButton);

        String result = getIntent().getStringExtra("result");
        resultTextview.setText("You " + result + "!");

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), WaitingRoomActivity.class);
                startActivity(intent);
                finishAffinity();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
