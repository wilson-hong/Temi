package com.hanyang.mobile;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Size;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.hanyang.mobile.decoder.Decoder;
import com.hanyang.mobile.entity.Temi;
import com.hanyang.mobile.network.EncodedData;
import com.hanyang.mobile.network.Network;
import com.hanyang.mobile.network.VideoSocketCallback;
import com.hanyang.mobile.network.WebSocketCallback;
import com.hanyang.mobile.network.dto.WebSocketMessage;

import java.util.List;
import java.util.UUID;

public class GameActivity extends AppCompatActivity {
    private MobileApplication mobileApplication;
    private Network network;
    private WifiManager.WifiLock wifiLock;
    private Decoder decoder;
    private Size outputSize = new Size(1280, 720);

    private ImageButton forwardButton;
    private ImageButton backwardButton;
    private ImageButton leftButton;
    private ImageButton rightButton;
    private ImageButton upButton;
    private ImageButton downButton;
    private ImageButton fireButton;
    private TextureView textureViewVideo;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        mobileApplication = (MobileApplication) getApplication();
        network = mobileApplication.getNetwork();

        forwardButton = (ImageButton) findViewById(R.id.forwardButton);
        backwardButton = (ImageButton) findViewById(R.id.backwardButton);
        leftButton = (ImageButton) findViewById(R.id.leftButton);
        rightButton = (ImageButton) findViewById(R.id.rightButton);
        upButton = (ImageButton) findViewById(R.id.upButton);
        downButton = (ImageButton) findViewById(R.id.downButton);
        fireButton = (ImageButton) findViewById(R.id.fireButton);
        textureViewVideo = (TextureView) findViewById(R.id.textureViewVideo);

        forwardButton.setOnTouchListener(touchListener(1));
        backwardButton.setOnTouchListener(touchListener(2));
        leftButton.setOnTouchListener(touchListener(3));
        rightButton.setOnTouchListener(touchListener(4));
        upButton.setOnTouchListener(touchListener(5));
        downButton.setOnTouchListener(touchListener(6));
        fireButton.setOnTouchListener((view, motionEvent) -> {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                network.pushCommand(7);
            }
            return true;
        });

        network.setWebSocketCallback(new WebSocketCallback() {
            @Override
            public void onConnected() {}

            @Override
            public void onDisonnected() {
                runOnUiThread(() -> Toast.makeText(getApplicationContext(), "Server Disconnected", Toast.LENGTH_SHORT).show());
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finishAffinity();
            }

            @Override
            public void onReceiveMessage(WebSocketMessage webSocketMessage) {
                if (webSocketMessage.cmd.equals("GAME_END")) {
                    String result = webSocketMessage.data;

                    Intent intent = new Intent(getApplicationContext(), GameEndActivity.class);
                    intent.putExtra("result", result.equals("win") ? "Win" : "Lose");
                    startActivity(intent);
                    finishAffinity();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        WifiManager wifiManager = (WifiManager)this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiLock = wifiManager.createWifiLock((Build.VERSION.SDK_INT >= 29) ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF, null);
        wifiLock.setReferenceCounted(true);
        wifiLock.acquire();

        if (textureViewVideo.isAvailable()) {
            initDecoder();
        } else {
            initTextureView();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        wifiLock.release();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    private View.OnTouchListener touchListener(Integer cmd) {
        View.OnTouchListener listener = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                switch (motionEvent.getAction()){
                    case MotionEvent.ACTION_DOWN:{
                        network.pushCommand(cmd);
                        return true;
                    }

                    case MotionEvent.ACTION_MOVE:{
                        return true;
                    }

                    case MotionEvent.ACTION_UP:{
                        network.pushCommand(-cmd);
                        return false;
                    }

                    default:
                        return false;
                }
            }
        };

        return listener;
    }

    private void initDecoder() {
        SurfaceTexture texture = textureViewVideo.getSurfaceTexture();
        texture.setDefaultBufferSize(outputSize.getWidth(), outputSize.getHeight());

        decoder = new Decoder(new Surface(texture));
        decoder.start();

        network.setVideoSocketCallback(new VideoSocketCallback() {
            @Override
            public void onConnected() {}

            @Override
            public void onReceiveData(EncodedData data) {
                decoder.pushEncodedData(data);
            }
        });

        network.pushCommand(1001);
    }

    private void initTextureView() {
        textureViewVideo.setSurfaceTextureListener(textureListener);
    }

    private TextureView.SurfaceTextureListener textureListener = new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(@NonNull SurfaceTexture surface, int width, int height) {
            Matrix matrix = new Matrix();
            float centerX = (float) textureViewVideo.getWidth() / 2f;
            float centerY = (float) textureViewVideo.getHeight() / 2f;
//            float scaleX = (float) textureViewVideo.getWidth() / textureViewVideo.getHeight();
//            float scaleY = (float) textureViewVideo.getHeight() / textureViewVideo.getWidth();
            float scaleX = 1;
            float scaleY = 1;
            matrix.postRotate(180f, centerX, centerY);
            matrix.postScale(scaleX, scaleY, centerX, centerY);
            textureViewVideo.setTransform(matrix);

            initDecoder();
        }

        @Override
        public void onSurfaceTextureSizeChanged(@NonNull SurfaceTexture surface, int width, int height) {
        }

        @Override
        public boolean onSurfaceTextureDestroyed(@NonNull SurfaceTexture surface) {
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(@NonNull SurfaceTexture surface) {

        }
    };
}
