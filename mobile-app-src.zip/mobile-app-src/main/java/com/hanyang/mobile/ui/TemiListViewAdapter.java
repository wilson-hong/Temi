package com.hanyang.mobile.ui;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.hanyang.mobile.MobileApplication;
import com.hanyang.mobile.R;
import com.hanyang.mobile.entity.Temi;
import com.hanyang.mobile.network.Network;

import java.util.List;

public class TemiListViewAdapter extends ArrayAdapter {
    Context context;
    Activity activity;
    MobileApplication mobileApplication;
    Network network;
    List<Temi> temis;

    public TemiListViewAdapter(@NonNull Context context, List<Temi> temis) {
        super(context, 0, temis);

        this.context = context;
        this.temis = temis;
        activity = (Activity)context;
        mobileApplication = (MobileApplication)activity.getApplication();
        network = mobileApplication.getNetwork();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_temi, parent, false);
        }
        Temi temi = (Temi) getItem(position);

        TextView name = (TextView) convertView.findViewById(R.id.nameTextView);
        ImageButton connectButton = (ImageButton) convertView.findViewById(R.id.connectButton);

        name.setText(temi.getName());
        if (!temi.getState().equals("idle")) {
            connectButton.setVisibility(View.INVISIBLE);
        }

        connectButton.setOnClickListener(view -> {
            network.cleanTemi();
            network.connectTemi(temi.getIp());
        });

        return convertView;
    }
}
