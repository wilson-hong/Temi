package com.hanyang.mobile;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private int REQUEST_CODE_PERMISSIONS = 1001;
    private final String[] REQUIRED_PERMISSIONS = new String[]{Manifest.permission.INTERNET};

    ImageButton startButton, settingButton, exitButton;
    Dialog popUp;
    Button musicButton, closePopup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startButton = (ImageButton) findViewById(R.id.startButton);
        settingButton = (ImageButton) findViewById(R.id.settingButton);
        exitButton = (ImageButton) findViewById(R.id.exitButton);

        initPopUp();

        settingButton.setOnClickListener(view -> popUp.show());

        startButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(intent);
            finishAffinity();
        });

        exitButton.setOnClickListener(view -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Do you want to exit?").setCancelable(false).
                    setPositiveButton("Yes", (dialogInterface, i) -> {
                        finish();
                        System.exit(0);
                    }).setNegativeButton("No", (dialogInterface, i) -> dialogInterface.cancel());
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        });

        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS);
        }
    }

    private void initPopUp() {
        popUp = new Dialog(MainActivity.this);
        popUp.setContentView(R.layout.activity_settings_popup);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1){
            popUp.getWindow().setBackgroundDrawable(getDrawable(R.drawable.popup_background));
        }

        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(popUp.getWindow().getAttributes());
        layoutParams.width = 950;
        layoutParams.height = 700;
        popUp.getWindow().setAttributes(layoutParams);
        popUp.getWindow().getAttributes().windowAnimations = R.style.animation;

        closePopup = popUp.findViewById(R.id.closePopup);

        closePopup.setOnClickListener(view -> {
            Toast.makeText(MainActivity.this, "Cancel", Toast.LENGTH_SHORT).show();
            popUp.dismiss();
        });

        closePopup.setOnClickListener(view -> {
            Toast.makeText(MainActivity.this, "Cancel", Toast.LENGTH_SHORT).show();
            popUp.dismiss();
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CODE_PERMISSIONS && 0 < grantResults.length) {
            if (allPermissionsGranted()) {

            } else {
                Toast.makeText(this, "Permissions not granted by the user.", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
        }
    }

    private boolean allPermissionsGranted() {
        for (String permission : REQUIRED_PERMISSIONS) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }

        return true;
    }
}