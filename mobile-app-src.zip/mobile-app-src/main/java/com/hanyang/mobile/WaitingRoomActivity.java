package com.hanyang.mobile;

import static com.hanyang.mobile.network.Network.STATUS_CONNECTED;

import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hanyang.mobile.entity.Player;
import com.hanyang.mobile.entity.Temi;
import com.hanyang.mobile.network.ControlSocketCallback;
import com.hanyang.mobile.network.Network;
import com.hanyang.mobile.network.WebSocketCallback;
import com.hanyang.mobile.network.dto.WebSocketMessage;
import com.hanyang.mobile.ui.TemiListViewAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class WaitingRoomActivity extends AppCompatActivity {
    private MobileApplication mobileApplication;
    private Network network;
    private ObjectMapper objectMapper;

    ImageButton backButton, redTeamButton, blueTeamButton;
    List<Pair<TableRow, TextView>> slots = new ArrayList<>();

    List<Player> players = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_waiting_room);
        mobileApplication = (MobileApplication) getApplication();
        network = mobileApplication.getNetwork();
        objectMapper = new ObjectMapper();

        backButton = (ImageButton) findViewById(R.id.backButton);
        redTeamButton = (ImageButton) findViewById(R.id.redTeamButton);
        blueTeamButton = (ImageButton) findViewById(R.id.blueTeamButton);

        for (int i = 0; i < 4; i++) {
            int resID = getResources().getIdentifier("slot_" + (i + 1), "id", getPackageName());
            TableRow tableRow = (TableRow)findViewById(resID);
            resID = getResources().getIdentifier("slotName_" + (i + 1), "id", getPackageName());
            TextView textView = (TextView)findViewById(resID);
            slots.add(new Pair<>(tableRow, textView));
        }

        network.setWebSocketCallback(new WebSocketCallback() {
            @Override
            public void onConnected() {}

            @Override
            public void onDisonnected() {
                runOnUiThread(() -> Toast.makeText(getApplicationContext(), "Server Disconnected", Toast.LENGTH_SHORT).show());
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finishAffinity();
            }

            @Override
            public void onReceiveMessage(WebSocketMessage webSocketMessage) {
                if (webSocketMessage.cmd.equals("PLAYER_LIST")) {
                    try {
                        players = objectMapper.readValue(webSocketMessage.data, new TypeReference<List<Player>>() {});
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }

                    runOnUiThread(() -> updateSlotsUI());
                } else if (webSocketMessage.cmd.equals("PLAYER_TEAM_CHANGED")) {
                    Player player = null;
                    try {
                        player = objectMapper.readValue(webSocketMessage.data, Player.class);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }

                    UUID uuid = player.getUuid();
                    Player target = players.stream()
                            .filter(x -> x.getUuid().equals(uuid))
                            .findAny()
                            .orElse(null);

                    if (target != null) {
                        target.setTeam(player.getTeam());
                        runOnUiThread(() -> updateSlotsUI());
                    }
                } else if (webSocketMessage.cmd.equals("GAME_START")) {
                    Intent intent = new Intent(getApplicationContext(), GameActivity.class);
                    startActivity(intent);
                    finishAffinity();
                }
            }
        });

        redTeamButton.setOnClickListener(view -> {
            network.sendToServer("PLAYER_SELECT_TEAM", "red");
            network.pushCommand(1011);
        });

        blueTeamButton.setOnClickListener(view -> {
            network.sendToServer("PLAYER_SELECT_TEAM", "blue");
            network.pushCommand(1012);
        });

        backButton.setOnClickListener(view -> {
            network.sendToServer("PLAYER_SELECT_TEAM", "none");
            network.pushCommand(1010);

            Intent intent = new Intent(getApplicationContext(), ConnectTemiActivity.class);
            startActivity(intent);
            finishAffinity();
        });

        network.sendToServer("GET_PLAYER_LIST", "");
    }

    private void updateSlotsUI() {
        for (int i = 0; i < 4; i++) {
            if (i < players.size()) {
                Player player = players.get(i);
                switch (player.getTeam()) {
                    case "none":
                        slots.get(i).first.setBackgroundResource(R.drawable.slot_none);
                        break;

                    case "red":
                        slots.get(i).first.setBackgroundResource(R.drawable.slot_red);
                        break;

                    case "blue":
                        slots.get(i).first.setBackgroundResource(R.drawable.slot_blue);
                        break;

                    default:
                        break;
                }
                slots.get(i).second.setText(player.getName());
            } else {
                slots.get(i).first.setBackgroundResource(R.drawable.slot_empty);
                slots.get(i).second.setText("");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
